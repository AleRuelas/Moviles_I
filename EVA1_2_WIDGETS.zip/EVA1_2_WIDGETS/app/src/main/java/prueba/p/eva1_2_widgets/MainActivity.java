package prueba.p.eva1_2_widgets;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtVwMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVwMe = findViewById(R.id.txtVwMensa);
        txtVwMe.setText("Hola mundo cruel");
        txtVwMe.setText(R.string.saludo);



    }
}
