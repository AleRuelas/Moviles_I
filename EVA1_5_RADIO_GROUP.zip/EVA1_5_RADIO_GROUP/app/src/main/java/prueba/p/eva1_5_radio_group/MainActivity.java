package prueba.p.eva1_5_radio_group;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
implements RadioGroup.OnCheckedChangeListener {
    RadioGroup rdGrpComida;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rdGrpComida = findViewById(R.id.rdGrpComida);
        rdGrpComida.setOnCheckedChangeListener(this);

    }


    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        String sMensa;
        if (i == R.id.radioButton){
            sMensa = "Tacos";
        } else if (i == R.id.radioButton2){
            sMensa = "Tortas";
        } else if (i == R.id.radioButton3){
            sMensa = "Montados";
        } else {
            sMensa = "Burritos";
        }


        Toast.makeText(this,sMensa,Toast.LENGTH_SHORT).show();
    }

}
