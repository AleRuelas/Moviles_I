package prueba.p.eva1_4_eventoss;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
implements View.OnClickListener{
    Button btnPorInt, getBtnPorClaseAn, btnPorClaseExt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPorInt = findViewById(R.id.btnPorInt);
        getBtnPorClaseAn = findViewById(R.id.btnPorClaseAn);



        btnPorInt.setOnClickListener(this);
        getBtnPorClaseAn.setOnClickListener(new View.OnClickListener() {
            //Interfaz convertida a una clase anonima, hay que cambiar el contexto
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Evento por clase anonima!",Toast.LENGTH_LONG).show();

            }
        });


        MiEventoClick meClick = new MiEventoClick();
        meClick.setContext(this);
        btnPorClaseExt.setOnClickListener(meClick);

    }

    public void miClick(View v){
        Toast.makeText(this, "Hola mundo!",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onClick(View view) {
        Toast.makeText(this, "Evento x listener!",Toast.LENGTH_LONG).show();
    }
}
