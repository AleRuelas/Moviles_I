package com.example.eva1_6_screen;
//MANEJO DE ORIENTACION DE LA PANTALLA
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnActivador;
    TextView txtVVista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnActivador = findViewById(R.id.btnActivador);
        txtVVista = findViewById(R.id.txtVVista);
        btnActivador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtVVista.append("asdfghjklzxcvbnmqwertyuiop Hasta aqui llego el abc. ");
            }
        });

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
            Log.wtf("Pantalla", "PORTRAIT");
        } else {
            Log.wtf("Pantalla", "LANDSCAPE");
        }

    }
}