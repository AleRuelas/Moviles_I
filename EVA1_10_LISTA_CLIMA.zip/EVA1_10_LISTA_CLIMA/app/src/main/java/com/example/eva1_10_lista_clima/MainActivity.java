package com.example.eva1_10_lista_clima;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements ListView.OnItemClickListener{
    ListView listaClima;

    Clima[] cCiudades = {
        new Clima(R.drawable.atmospher,"Aldama", 25,"chido" ),
            new Clima(R.drawable.cloudy,"Camargo", 28,"Nice!" ),
            new Clima(R.drawable.light_rain,"Parral", 18.5,"Lluvioso" ),
            new Clima(R.drawable.rainy,"Madera", 17,"Melancolico" ),
            new Clima(R.drawable.snow,"Creel", -7,"Nevadas" ),
            new Clima(R.drawable.thunderstorm,"Jimenez", 16,":Lluvias intensas" ),
            new Clima(R.drawable.tornado,"Delicias", 26,"Run like hell" )
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaClima = findViewById(R.id.listaClima);
        listaClima.setAdapter(new ClimaAdapter(this, R.layout.layout_clima,cCiudades));
        listaClima.setOnItemClickListener(this);

    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this, cCiudades[i].getCiudad(), Toast.LENGTH_LONG).show();
    }
}
